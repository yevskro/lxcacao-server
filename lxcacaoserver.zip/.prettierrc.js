module.exports = {
    singleQuote: true,
    printWidth: 80,
  };